# STEP 4 — 학생 오류 유형 군집화 구현·검증 결과 (v1.0)

실행일: 2026-11-04 (Asia/Seoul). 입력 오류 후보는 STEP 1에서 무작위 시뮬레이션으로 생성되었습니다.

## 결과의 의미

- **구현 성공:** 기본 60개 조합, 조합별 부트스트랩 200회, 문항 제거, train 전용 선정, 14개 민감도 조건 및 선정 모델의 holdout 평가가 완료되었습니다.
- **탐색적 군집 발견:** `item_sqrt_kmeans_k2`를 PoC 비교용 모델로 선정했습니다. 군집별 Jaccard가 0.40을 넘었지만 모두 0.75 미만이며, 학생 구성 변화에 대한 ARI가 낮습니다. 견고한 학생 유형이 확인되었다는 결론은 보류합니다.
- **교육적 유효성 검증:** 수행되지 않았습니다. 실제 오류 원인 데이터와 전문가 검증이 별도로 필요합니다. 군집을 학생의 학습 결함이나 검증된 교육적 유형으로 명명하지 않습니다.

## 코드·환경·실행 명령

- [tools/run_step4.py](tools/run_step4.py): 입력 무결성, 원자료 재계산, 모델 비교, 부트스트랩, 문항 제거, 선정, holdout, 민감도 및 저장 검증.
- [test_step4.py](test_step4.py): 자동 테스트 19개. 실제 STEP 3-2 CSV와 재계산 벡터 일치 테스트 포함.
- [requirements_step4.txt](requirements_step4.txt): 실제 실행 환경의 패키지 버전 고정.
- 기존 STEP 1~3-2 코드·노트북·산출물 50개 파일의 작업 전후 SHA-256이 동일합니다.

실제 사용한 환경 설치 명령:

```bash
uv --cache-dir /tmp/chunjae-step4-cache venv --python /Library/Frameworks/Python.framework/Versions/3.10/bin/python3.10 --system-site-packages /tmp/chunjae-step4-venv
uv --cache-dir /tmp/chunjae-step4-cache pip install --python /tmp/chunjae-step4-venv/bin/python 'scikit-learn==1.7.2'
```

실제 전체 실험 명령:

```bash
LOKY_MAX_CPU_COUNT=1 /tmp/chunjae-step4-venv/bin/python tools/run_step4.py --step3-2-output-dir step3_2_output --step3-output-dir step3_output --output-dir step4_output --bootstrap-iterations 200
```

위 명령은 자동 테스트 19개를 먼저 실행하며 모두 통과했습니다. 전체 실행 종료 코드는 0입니다. `--tests-only`로 테스트만 실행할 수 있습니다. 임시 환경이 삭제되면 Python 3.10 가상환경을 만들고 `python -m pip install -r requirements_step4.txt`로 재구성합니다. 모든 입력·출력 기본 경로는 프로젝트 루트에 상대적으로 정해집니다.

실행 환경: Python 3.10.2, NumPy 2.2.6, SciPy 1.15.3, scikit-learn 1.7.2, joblib 1.6.0, threadpoolctl 3.7.0. seed=42, K-means++/n_init=50, 수치 스레드 수 1입니다. `LOKY_MAX_CPU_COUNT=1`은 샌드박스의 CPU 개수 탐지 경고를 피하기 위한 설정입니다.

## 입력 및 출력

전체 1,726명, 프로파일 보유 1,290명, 군집화 가능 357명, train 285명, holdout 72명, excluded 1,369명으로 STEP 3-2 기준과 일치합니다. 군집화 입력은 세 방식 모두 같은 train 285명입니다. 기존 학생 분할을 그대로 유지했습니다.

| 출력 파일 | 행 수 | 컬럼 수 |
|---|---:|---:|
| [step4_cluster_assignments.csv](step4_output/step4_cluster_assignments.csv) | 17,172 | 12 |
| [step4_cluster_profiles.csv](step4_output/step4_cluster_profiles.csv) | 1,200 | 10 |
| [step4_model_comparison.csv](step4_output/step4_model_comparison.csv) | 60 | 14 |
| [step4_cluster_validation.csv](step4_output/step4_cluster_validation.csv) | 55,522 | 11 |
| [step4_sensitivity_analysis.csv](step4_output/step4_sensitivity_analysis.csv) | 14 | 10 |

모든 CSV는 UTF-8-SIG입니다. ID는 문자열이며 실수는 반올림 없이 저장합니다. 배정 17,172행은 60개 비교 모델 × train 285명 + 선정 모델 holdout 72명입니다. 비선정 모델의 holdout 배정은 없습니다. 군집 프로파일 CSV는 train 통계이고 holdout 차이는 검증 CSV에 기록합니다.

## 비교·검증 정의

- 기본 비교: individual/item/smoothed × raw/sqrt × K-means/Ward × K=2~6 = **60개**. 주 실험 36개(K=2~4), 보조 실험 24개(K=5~6).
- 원본 비중은 그대로 사용하고 sqrt는 각 성분에 제곱근만 적용합니다. 표준화·추가 정규화는 하지 않습니다. sqrt 성분이나 중심을 실제 오류 비중으로 해석하지 않습니다.
- 부트스트랩: 모델당 train 학생 수만큼 복원추출, 200회. 동일 seed의 추출 순서를 설정 간 공유합니다. 원래 군집과 재표집 군집 모두 해당 반복의 **고유 in-bag 학생 ID**로 제한한 후, 원래 군집마다 최대 Jaccard인 재표집 군집을 독립적으로 찾습니다. 일대일 매칭 제약은 두지 않습니다. 미추출 학생은 양쪽 비교에서 제외하고, 원래 군집이 표본에서 비면 해당 군집의 반복을 결측으로 기록합니다.
- 동일 학생이 여러 번 추출되면 학습에는 중복 행을 유지하지만 Jaccard 집합에는 한 번만 포함합니다. 표본의 고유 학생 수/벡터 수 부족, 동일 학생의 복수 군집 분산 등 유효하지 않은 반복은 사유와 실패 횟수를 기록합니다. 실패를 성공으로 세지 않습니다.
- 기본 실험 12,000회와 새 민감도 조건 800회를 합쳐 **12,800회**의 부트스트랩을 실제 수행했습니다. 동일한 민감도 조건은 기존 200회 결과를 재사용했습니다. 실제 재표집 실패는 0회입니다.
- 문항 제거: 학생×고유 매칭 오답 문항을 한 번에 제거하여 그 문항의 모든 반복 풀이·빈칸 단위를 함께 제외합니다. 개별합은 남은 단위 수, 문항합은 남은 고유 문항 수를 분모로 사용합니다. smoothed는 고정 prior·alpha와 줄어든 문항 수를 사용합니다. 5→4문항 학생도 그대로 평가합니다.
- 문항 제거 뒤 모델을 재학습하지 않고 고정 중심의 nearest-centroid로 배정하여 원래 학습 군집과 비교합니다. Ward는 제거 전에도 이 규칙의 배정과 원래 군집이 다를 수 있어 `unperturbed_nearest_centroid_agreement`도 저장합니다.
- 학생별 `student_agreement`, `student_mean_tvd`, `student_max_tvd`를 검증 CSV에 저장합니다. 학생 ID는 notes의 `student_id=`로 추적합니다. TVD는 변환 전 비중으로 계산합니다. 전체 일치율은 학생×문항 제거 건을 동일 가중치로 합산한 값입니다.
- 배정 거리는 실제 배정 군집 중심까지의 거리입니다. margin은 두 번째로 가까운 중심 거리 − 가장 가까운 중심 거리이며 확률이 아닙니다. Ward train에서는 실제 배정 군집이 가장 가까운 중심과 다를 수 있습니다.
- 군집 프로파일의 평균·중앙값·모집단 표준편차(ddof=0)·전체 평균 차이는 모두 변환 전 비중으로 계산합니다.

## 사전에 고정한 선정 규칙과 실제 선정 이유

선정은 train에서만 수행했고, 아래 규칙은 전체 실험을 실행하기 전에 코드에 명시했습니다. 임의 가중 종합점수는 사용하지 않았습니다.

1. K=2~4를 선정 대상으로 삼습니다. 군집별 Jaccard<0.40, 유효 부트스트랩 비율<95%, 문항 제거 일치율<0.80, silhouette≤0 또는 지표 결측 모델은 제외합니다. 0.80과 95%는 운영상 탐색 기준으로 통계적 검증 기준이 아닙니다.
2. 문항 제거 일치율이 최고값에서 0.01 이내인 모델을 유지합니다. 그 안에서 최저 군집 Jaccard가 최고값에서 0.02 이내인 모델을 유지합니다.
3. silhouette는 **raw/sqrt 각각의 표현 안에서만** 최고값 대비 0.02 이내를 유지합니다. raw와 sqrt 점수만으로 우열을 정하지 않습니다.
4. 최소 군집 크기 `max(10, ceil(0.05×285))=15명`을 만족하는 후보가 있으면 해당 후보를 우선합니다. 미달 결과도 삭제하지 않습니다.
5. 변환 전 군집 평균 비중 사이의 평균 TVD를 서술적 구분 정도로 보고 최고값 대비 0.02 이내를 유지합니다. 이는 교육적 해석 가능성의 검증을 대신하지 않습니다.
6. 남은 후보에서 작은 K → item → raw → K-means를 우선합니다. 조건을 만족하는 모델이 없으면 `no_model_selected`로 기록하고 holdout을 평가하지 않습니다.

실제로 초기 기준을 통과한 주 실험 후보는 20개였습니다. 문항 제거 최고값은 individual/raw/K-means/K=2의 0.936556이며, 0.01 이내 후보는 다음 네 개였습니다.

| 모델 | 문항 제거 일치율 | 최저 군집 Jaccard | 군집 평균 간 원본 TVD |
|---|---:|---:|---:|
| individual_raw_kmeans_k2 | 0.936556 | 0.527406 | 0.176568 |
| individual_sqrt_kmeans_k2 | 0.927795 | 0.511054 | 0.163951 |
| item_sqrt_kmeans_k2 | 0.934743 | 0.529097 | 0.191107 |
| smoothed_sqrt_kmeans_k2 | 0.932628 | 0.513324 | 0.147951 |

위 네 모델은 Jaccard·표현 내부 silhouette·최소 크기 조건을 통과했습니다. 군집 평균 차이 기준에서는 individual/raw와 item/sqrt가 남았고, 같은 K에서 문항합 우선 원칙으로 **item/sqrt/K-means/K=2**를 선정했습니다. 기본 기준 모델 item/raw/K-means/K=2의 문항 제거 일치율 0.918127은 최고값 대비 0.01 범위에 들지 못했습니다. sqrt의 silhouette가 더 높아서 선정한 것이 아닙니다.

선정은 민감도·holdout 결과를 보기 전에 동결했습니다. 이후 결과를 근거로 모델이나 K를 다시 고르지 않았습니다. 민감도 결과가 약하므로 이번 선정은 PoC 평가 대상의 확정을 뜻하며 실제 적용 모델의 채택을 뜻하지 않습니다.

## K=2~4 주요 실험 결과

| 모델 | Silhouette | 평균 Jaccard | 최저 Jaccard | 문항 제거 일치율 | 최소/최대 크기 | 상태 |
|---|---:|---:|---:|---:|---:|---|
| individual_raw_kmeans_k2 | 0.167877 | 0.560342 | 0.527406 | 0.936556 | 124/161 | candidate |
| individual_raw_kmeans_k3 | 0.173914 | 0.530631 | 0.497141 | 0.893353 | 67/109 | candidate |
| individual_raw_kmeans_k4 | 0.183023 | 0.598364 | 0.585934 | 0.883384 | 56/78 | candidate |
| individual_raw_ward_k2 | 0.168880 | 0.481987 | 0.373496 | 0.783686 | 90/195 | rejected |
| individual_raw_ward_k3 | 0.146404 | 0.383555 | 0.310487 | 0.831420 | 44/195 | rejected |
| individual_raw_ward_k4 | 0.155500 | 0.397360 | 0.368773 | 0.793353 | 44/143 | rejected |
| individual_sqrt_kmeans_k2 | 0.162950 | 0.561469 | 0.511054 | 0.927795 | 109/176 | candidate |
| individual_sqrt_kmeans_k3 | 0.169230 | 0.539437 | 0.524779 | 0.900000 | 76/119 | candidate |
| individual_sqrt_kmeans_k4 | 0.162219 | 0.556358 | 0.510850 | 0.885801 | 58/85 | candidate |
| individual_sqrt_ward_k2 | 0.137392 | 0.470251 | 0.287955 | 0.894260 | 58/227 | rejected |
| individual_sqrt_ward_k3 | 0.128059 | 0.392760 | 0.345965 | 0.807553 | 58/154 | rejected |
| individual_sqrt_ward_k4 | 0.121082 | 0.373913 | 0.319617 | 0.724471 | 58/90 | rejected |
| item_raw_kmeans_k2 | 0.173305 | 0.581464 | 0.537018 | 0.918127 | 122/163 | candidate |
| item_raw_kmeans_k3 | 0.183653 | 0.640522 | 0.603555 | 0.889426 | 63/119 | candidate |
| item_raw_kmeans_k4 | 0.196083 | 0.657022 | 0.559828 | 0.888218 | 55/100 | candidate |
| item_raw_ward_k2 | 0.140417 | 0.496693 | 0.399765 | 0.906344 | 78/207 | rejected |
| item_raw_ward_k3 | 0.147394 | 0.465708 | 0.433578 | 0.853474 | 75/132 | candidate |
| item_raw_ward_k4 | 0.163917 | 0.462775 | 0.380232 | 0.804532 | 44/88 | rejected |
| item_sqrt_kmeans_k2 | 0.172586 | 0.585299 | 0.529097 | 0.934743 | 112/173 | selected |
| item_sqrt_kmeans_k3 | 0.159699 | 0.523301 | 0.480700 | 0.896979 | 62/125 | candidate |
| item_sqrt_kmeans_k4 | 0.161070 | 0.501310 | 0.471764 | 0.873112 | 45/86 | candidate |
| item_sqrt_ward_k2 | 0.108443 | 0.518923 | 0.447110 | 0.715408 | 112/173 | rejected |
| item_sqrt_ward_k3 | 0.123314 | 0.385172 | 0.259612 | 0.731118 | 49/124 | rejected |
| item_sqrt_ward_k4 | 0.130887 | 0.414173 | 0.295232 | 0.746828 | 11/124 | rejected |
| smoothed_raw_kmeans_k2 | 0.175837 | 0.561011 | 0.521940 | 0.914199 | 123/162 | candidate |
| smoothed_raw_kmeans_k3 | 0.185705 | 0.636538 | 0.610799 | 0.883988 | 76/105 | candidate |
| smoothed_raw_kmeans_k4 | 0.199006 | 0.666329 | 0.586002 | 0.867372 | 55/80 | candidate |
| smoothed_raw_ward_k2 | 0.156989 | 0.499869 | 0.366406 | 0.917523 | 62/223 | rejected |
| smoothed_raw_ward_k3 | 0.144546 | 0.479001 | 0.454813 | 0.820242 | 62/142 | candidate |
| smoothed_raw_ward_k4 | 0.154576 | 0.453639 | 0.342398 | 0.792749 | 40/102 | rejected |
| smoothed_sqrt_kmeans_k2 | 0.179673 | 0.558675 | 0.513324 | 0.932628 | 114/171 | candidate |
| smoothed_sqrt_kmeans_k3 | 0.173010 | 0.540007 | 0.512649 | 0.894562 | 67/117 | candidate |
| smoothed_sqrt_kmeans_k4 | 0.177264 | 0.528076 | 0.489870 | 0.875831 | 52/87 | candidate |
| smoothed_sqrt_ward_k2 | 0.113588 | 0.446454 | 0.385086 | 0.844411 | 98/187 | rejected |
| smoothed_sqrt_ward_k3 | 0.115408 | 0.382559 | 0.350343 | 0.798187 | 74/113 | rejected |
| smoothed_sqrt_ward_k4 | 0.103946 | 0.333921 | 0.272646 | 0.766163 | 42/113 | rejected |

## 집계·표현·알고리즘 비교

아래는 K=2~4의 균형 잡힌 설정들을 단순 평균한 서술 통계입니다. 새로운 선정 점수나 통계적 우월성 검정이 아닙니다. raw/sqrt의 silhouette 평균을 서로 비교하여 순위를 정하지 않았습니다.

| 구분 | 설정 수 | 평균 Jaccard | 평균 문항 제거 일치율 | 모든 군집 Jaccard≥0.40 모델 수 |
|---|---:|---:|---:|---:|
| vector_method=individual | 12 | 0.487202 | 0.855136 | 6/12 |
| vector_method=item | 12 | 0.519364 | 0.846526 | 8/12 |
| vector_method=smoothed | 12 | 0.507173 | 0.858988 | 7/12 |
| transform_method=raw | 18 | 0.530712 | 0.865441 | 11/18 |
| transform_method=sqrt | 18 | 0.478448 | 0.841658 | 10/18 |
| algorithm=kmeans | 18 | 0.573675 | 0.899782 | 18/18 |
| algorithm=ward | 18 | 0.435484 | 0.807318 | 3/18 |

K-means는 주 실험 18개 모두 군집별 0.40 기준을 넘었고 Ward는 18개 중 3개였습니다. Ward는 원래 계층 군집과 중심 배정의 차이가 문항 제거 일치율에 포함되므로 별도 무변경 기준값과 함께 해석해야 합니다. 베이지안이 모든 조건에서 우월하지 않았으며, 평균 안정성만으로 alpha=2를 최적값으로 확정하지 않았습니다.

## 모든 모델의 군집별 부트스트랩 Jaccard

기본 60개 모델 중 **35개**가 모든 군집의 평균 Jaccard≥0.40을 만족했습니다. 240개 개별 군집 판정은 stable 9개, exploratory_pass 177개, unstable 54개입니다. 이 기준을 통과했다는 이유만으로 모델을 선정하지 않았습니다. 비교표 상태는 selected 1개, candidate 31개, rejected 28개이며 후보 상태에는 선정하지 않은 보조 K 모델도 포함됩니다.

| 모델 | 군집 0부터의 평균 Jaccard | 모든 군집 ≥0.40 |
|---|---|---|
| individual_raw_kmeans_k2 | 0.5933, 0.5274 | 통과 |
| individual_raw_kmeans_k3 | 0.4971, 0.5831, 0.5116 | 통과 |
| individual_raw_kmeans_k4 | 0.5859, 0.6023, 0.5876, 0.6176 | 통과 |
| individual_raw_kmeans_k5 | 0.7914, 0.7107, 0.7417, 0.6889, 0.6785 | 통과 |
| individual_raw_kmeans_k6 | 0.4664, 0.6189, 0.7148, 0.5675, 0.5376, 0.6338 | 통과 |
| individual_raw_ward_k2 | 0.3735, 0.5905 | 미통과 |
| individual_raw_ward_k3 | 0.3105, 0.3429, 0.4973 | 미통과 |
| individual_raw_ward_k4 | 0.3688, 0.3743, 0.4609, 0.3855 | 미통과 |
| individual_raw_ward_k5 | 0.3941, 0.3919, 0.3696, 0.3630, 0.4107 | 미통과 |
| individual_raw_ward_k6 | 0.4196, 0.4019, 0.3827, 0.2947, 0.3764, 0.4084 | 미통과 |
| individual_sqrt_kmeans_k2 | 0.6119, 0.5111 | 통과 |
| individual_sqrt_kmeans_k3 | 0.5286, 0.5650, 0.5248 | 통과 |
| individual_sqrt_kmeans_k4 | 0.5631, 0.5889, 0.5625, 0.5108 | 통과 |
| individual_sqrt_kmeans_k5 | 0.5535, 0.5622, 0.4618, 0.5006, 0.5167 | 통과 |
| individual_sqrt_kmeans_k6 | 0.5409, 0.6058, 0.5179, 0.5531, 0.5926, 0.6845 | 통과 |
| individual_sqrt_ward_k2 | 0.6525, 0.2880 | 미통과 |
| individual_sqrt_ward_k3 | 0.3460, 0.4812, 0.3511 | 미통과 |
| individual_sqrt_ward_k4 | 0.3664, 0.3196, 0.4170, 0.3927 | 미통과 |
| individual_sqrt_ward_k5 | 0.3825, 0.4302, 0.3361, 0.4230, 0.4089 | 미통과 |
| individual_sqrt_ward_k6 | 0.4202, 0.4568, 0.3553, 0.4110, 0.4478, 0.6910 | 미통과 |
| item_raw_kmeans_k2 | 0.6259, 0.5370 | 통과 |
| item_raw_kmeans_k3 | 0.6550, 0.6630, 0.6036 | 통과 |
| item_raw_kmeans_k4 | 0.7296, 0.6983, 0.5598, 0.6404 | 통과 |
| item_raw_kmeans_k5 | 0.8399, 0.7479, 0.8029, 0.6883, 0.7402 | 통과 |
| item_raw_kmeans_k6 | 0.4033, 0.7224, 0.5740, 0.7023, 0.6362, 0.6872 | 통과 |
| item_raw_ward_k2 | 0.3998, 0.5936 | 미통과 |
| item_raw_ward_k3 | 0.4796, 0.4840, 0.4336 | 통과 |
| item_raw_ward_k4 | 0.5203, 0.5411, 0.3802, 0.4094 | 미통과 |
| item_raw_ward_k5 | 0.5445, 0.5580, 0.4466, 0.4348, 0.5037 | 통과 |
| item_raw_ward_k6 | 0.5189, 0.5331, 0.4048, 0.4057, 0.4424, 0.5595 | 통과 |
| item_sqrt_kmeans_k2 | 0.6415, 0.5291 | 통과 |
| item_sqrt_kmeans_k3 | 0.5294, 0.5598, 0.4807 | 통과 |
| item_sqrt_kmeans_k4 | 0.5019, 0.5013, 0.5303, 0.4718 | 통과 |
| item_sqrt_kmeans_k5 | 0.5396, 0.5519, 0.4442, 0.4281, 0.4658 | 통과 |
| item_sqrt_kmeans_k6 | 0.4945, 0.5309, 0.5218, 0.5225, 0.5839, 0.6339 | 통과 |
| item_sqrt_ward_k2 | 0.5907, 0.4471 | 통과 |
| item_sqrt_ward_k3 | 0.2596, 0.4651, 0.4308 | 미통과 |
| item_sqrt_ward_k4 | 0.2952, 0.4287, 0.4263, 0.5065 | 미통과 |
| item_sqrt_ward_k5 | 0.3251, 0.4129, 0.3645, 0.4312, 0.5973 | 미통과 |
| item_sqrt_ward_k6 | 0.3364, 0.3514, 0.3827, 0.4236, 0.3123, 0.6935 | 미통과 |
| smoothed_raw_kmeans_k2 | 0.6001, 0.5219 | 통과 |
| smoothed_raw_kmeans_k3 | 0.6349, 0.6640, 0.6108 | 통과 |
| smoothed_raw_kmeans_k4 | 0.7636, 0.5860, 0.6553, 0.6604 | 통과 |
| smoothed_raw_kmeans_k5 | 0.7583, 0.8568, 0.8103, 0.7027, 0.7795 | 통과 |
| smoothed_raw_kmeans_k6 | 0.4616, 0.7101, 0.7707, 0.6510, 0.4823, 0.7197 | 통과 |
| smoothed_raw_ward_k2 | 0.3664, 0.6333 | 미통과 |
| smoothed_raw_ward_k3 | 0.4900, 0.4548, 0.4921 | 통과 |
| smoothed_raw_ward_k4 | 0.5428, 0.5105, 0.4188, 0.3424 | 미통과 |
| smoothed_raw_ward_k5 | 0.3654, 0.5635, 0.5250, 0.3956, 0.4269 | 미통과 |
| smoothed_raw_ward_k6 | 0.3756, 0.4021, 0.5229, 0.4142, 0.3846, 0.4352 | 미통과 |
| smoothed_sqrt_kmeans_k2 | 0.6040, 0.5133 | 통과 |
| smoothed_sqrt_kmeans_k3 | 0.5315, 0.5759, 0.5126 | 통과 |
| smoothed_sqrt_kmeans_k4 | 0.5637, 0.4899, 0.5006, 0.5581 | 통과 |
| smoothed_sqrt_kmeans_k5 | 0.4862, 0.5327, 0.4884, 0.5642, 0.4991 | 통과 |
| smoothed_sqrt_kmeans_k6 | 0.5182, 0.5366, 0.4523, 0.5446, 0.5230, 0.4045 | 통과 |
| smoothed_sqrt_ward_k2 | 0.3851, 0.5078 | 미통과 |
| smoothed_sqrt_ward_k3 | 0.3503, 0.4087, 0.3886 | 미통과 |
| smoothed_sqrt_ward_k4 | 0.3446, 0.3596, 0.2726, 0.3589 | 미통과 |
| smoothed_sqrt_ward_k5 | 0.3354, 0.3785, 0.2893, 0.4022, 0.3445 | 미통과 |
| smoothed_sqrt_ward_k6 | 0.2406, 0.3808, 0.3047, 0.4087, 0.3384, 0.3417 | 미통과 |

0.75 이상 stable, 0.40 이상 0.75 미만 exploratory_pass, 0.40 미만 unstable입니다. **0.40은 이번 PoC의 완화된 기준이며 통계적 신뢰성·교육적 유효성을 보장하지 않습니다.**

## 선정 모델과 holdout

| 지표 | Train | Holdout |
|---|---:|---:|
| 학생 수 | 285 | 72 |
| Silhouette | 0.172586 | 0.134804 |
| 문항 제거 일치율 | 0.934743 | 0.890039 |
| 문항 제거 시행 수 | 3310 | 773 |
| 문항 제거 평균 TVD | 0.051183 | 0.054578 |

| 군집 | Train 학생 수 | Holdout 학생 수 | Train 평균 Jaccard | 판정 |
|---|---:|---:|---:|---|
| 0 | 173 | 37 | 0.641500 | exploratory_pass |
| 1 | 112 | 35 | 0.529097 | exploratory_pass |

Train/holdout 군집 크기 분포 TVD는 0.093129입니다. Holdout은 고정된 train 중심으로 nearest-centroid 배정했고 중심·K·alpha를 재학습하거나 재선정하지 않았습니다.

선정 모델의 train 평균 비중과 holdout 평균 비중 차이(holdout−train)는 다음과 같습니다. 원본 비중이며 실제 학습 결함을 뜻하지 않습니다.

| 군집 | 오류 대분류 | Train 평균 | Holdout−Train |
|---|---|---:|---:|
| 0 | 개념 이해 오류 | 0.177243 | -0.010947 |
| 0 | 계산 오류 | 0.215774 | 0.008918 |
| 0 | 규칙 적용 오류 | 0.188504 | -0.000753 |
| 0 | 선행 지식 부족 | 0.248097 | 0.002783 |
| 0 | 조건 해석 오류 | 0.170382 | -0.000001 |
| 1 | 개념 이해 오류 | 0.219727 | -0.004733 |
| 1 | 계산 오류 | 0.146343 | 0.011693 |
| 1 | 규칙 적용 오류 | 0.233513 | -0.010548 |
| 1 | 선행 지식 부족 | 0.126421 | 0.012889 |
| 1 | 조건 해석 오류 | 0.273996 | -0.009302 |

두 군집의 Jaccard는 0.641500·0.529097로 stable 기준 0.75에는 못 미칩니다. Silhouette도 0.17 수준으로 분리도가 강하다고 보기 어렵습니다. Holdout 문항 제거 일치율은 train보다 약 4.47%p 낮아졌으며 이 결과를 그대로 기록했습니다.

## 민감도 분석

한 번에 한 파라미터를 바꾸는 14개 조건입니다. 최소 문항 수·매칭률·K의 기준 모델은 선정 모델입니다. alpha 비교는 같은 sqrt/K-means/K=2의 **smoothed alpha=2**를 기준으로 ARI를 계산합니다. 모든 ARI는 기준과 변경 조건에 공통으로 포함된 학생만 사용합니다.

| 파라미터 | 값 | Train 학생 수 | 제외 증가 | Silhouette | 평균 Jaccard | 최저 Jaccard | 문항 제거 일치율 | 공통 학생 ARI |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| min_items | 3 | 285 | 0 | 0.172586 | 0.585299 | 0.529097 | 0.934743 | 1.000000 |
| min_items | 5 | 285 | 0 | 0.172586 | 0.585299 | 0.529097 | 0.934743 | 1.000000 |
| min_items | 7 | 182 | 103 | 0.182586 | 0.713879 | 0.697298 | 0.943013 | 0.042281 |
| min_coverage | 0.7 | 285 | 0 | 0.172586 | 0.585299 | 0.529097 | 0.934743 | 1.000000 |
| min_coverage | 0.8 | 285 | 0 | 0.172586 | 0.585299 | 0.529097 | 0.934743 | 1.000000 |
| min_coverage | 0.9 | 229 | 56 | 0.172873 | 0.603834 | 0.560695 | 0.929742 | -0.000264 |
| alpha | 0 | 285 | 0 | 0.172586 | 0.585299 | 0.529097 | 0.934743 | 0.971985 |
| alpha | 2 | 285 | 0 | 0.179673 | 0.558675 | 0.513324 | 0.932628 | 1.000000 |
| alpha | 5 | 285 | 0 | 0.174245 | 0.603584 | 0.587257 | 0.928399 | 0.013323 |
| n_clusters | 2 | 285 | 0 | 0.172586 | 0.585299 | 0.529097 | 0.934743 | 1.000000 |
| n_clusters | 3 | 285 | 0 | 0.159699 | 0.523301 | 0.480700 | 0.896979 | 0.105988 |
| n_clusters | 4 | 285 | 0 | 0.161070 | 0.501310 | 0.471764 | 0.873112 | 0.101288 |
| n_clusters | 5 | 285 | 0 | 0.166245 | 0.485926 | 0.428122 | 0.867976 | 0.139969 |
| n_clusters | 6 | 285 | 0 | 0.174390 | 0.547916 | 0.494488 | 0.865861 | 0.161637 |

- 최소 문항 3·5, 매칭률 0.70·0.80은 모두 기존 train 285명을 유지합니다. excluded나 holdout을 새로 train에 편입하지 않았기 때문에 완화 조건에서 표본이 늘지 않습니다.
- 최소 문항 7에서는 103명이 빠져 182명이고, 매칭률 0.90에서는 56명이 빠져 229명입니다. 해당 train 집합으로 필요한 prior만 재계산했습니다.
- **구성 변화 민감성이 큽니다.** 최소 문항 7의 공통 학생 ARI는 0.042281, 매칭률 0.90의 ARI는 −0.000264입니다. 일부 안정성 지표가 개선되어도 기존 배정과 거의 일치하지 않으므로 견고한 구조로 단정할 수 없습니다.
- alpha=5는 smoothed alpha=2 기준 ARI 0.013323으로 배정이 크게 변합니다. alpha=0은 문항합과 같은 비중이며 ARI 기준은 smoothed alpha=2이므로 반드시 1이 되는 비교가 아닙니다.
- K=2→6에서 선택 계열의 문항 제거 일치율은 0.934743→0.865861로 낮아집니다. K=5~6은 보조 실험 결과로 보존했고 최종 선정 후보로 자동 승격하지 않았습니다.
- 민감도 결과는 진단용으로 기록했으며 이후 holdout을 근거로 모델을 다시 고르지 않았습니다.

## 자동 검증 및 남은 한계

검증 CSV 상태: PASS 285개, FAIL 0개, INFO 54,989개, exploratory_pass 185개, stable 9개, unstable 54개입니다. 이 중 무결성(integrity) PASS는 221개이고 나머지 PASS 64개는 부트스트랩 실패 0회 기록입니다. 전체 bootstrap 상태에는 별도 민감도 재학습 군집 8개가 포함됩니다. **FAIL 0은 구현 무결성 결과이며 불안정 군집이 없다는 뜻이 아닙니다.**

자동 테스트 19개는 수기 예제의 반복 문항·빈칸 집계, 원자료↔STEP 3-2 벡터 일치, 잘못된 가중치 거부, sqrt 표현, seed 재현성·ARI 라벨 불변성, 과도한 K 처리, 고유 in-bag Jaccard·미관측 군집 처리, 재표집 실패 미성공 처리, 부트스트랩 재현성, 거리 margin, 원본 비중 프로파일, holdout 변경 시 train 결과 불변, 선정 보류 시 holdout 미사용, 낮은 군집 Jaccard의 선정 차단, holdout 무재학습, silhouette NA 사유, 민감도 train 집합 고정, 기준 모델 부재의 NA 및 출력 경로 보호를 검증합니다.

실제 실행에서도 기본 60개 및 추가 민감도 모델을 같은 설정으로 두 번 적합하여 ARI=1과 중심 일치를 확인했습니다. 입력 해시, 출력 기본키, 60개 조합, 군집 수·크기, 모든 train 배정, 선정 플래그, holdout의 선정 모델 한정, 14개 민감도 조건, CSV 재읽기와 정확한 컬럼 순서를 검증했습니다. 재표집에 따른 불안정성과 구현 오류를 구분해 기록합니다.

지표가 계산 불가능하면 NA와 사유를 저장합니다. 실제 데이터에서는 기본·민감도·holdout 평가 지표의 계산 불능이나 재표집 실패가 없었습니다. 현재 표본은 시뮬레이션 오류 후보에서 나온 비중이므로, 실제 학생 유형의 존재·진단 정확도·교육적 효과를 검증한 결과가 아닙니다. 다음 단계에서 실제 원인 라벨 및 전문가 평가를 확보하기 전에는 이 군집을 교육적 의사결정에 확정적으로 사용하지 않습니다.

알고리즘 API와 거리 해석의 참고 문서: [scikit-learn KMeans](https://scikit-learn.org/1.7/modules/generated/sklearn.cluster.KMeans.html), [AgglomerativeClustering](https://scikit-learn.org/1.7/modules/generated/sklearn.cluster.AgglomerativeClustering.html). 수치 결과는 연결된 외부 사례가 아니라 현재 프로젝트 CSV로 계산했습니다.
